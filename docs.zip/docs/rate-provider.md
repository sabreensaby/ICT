Rate Provider
================
