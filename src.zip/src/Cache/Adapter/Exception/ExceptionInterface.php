<?php
namespace CurrencyConverter\Cache\Adapter\Exception;

interface ExceptionInterface extends \CurrencyConverter\Exception\ExceptionInterface
{    
}
