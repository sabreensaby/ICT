<?php
namespace CurrencyConverter\Cache\Adapter\Exception;

class CachePathNotFoundException extends \RuntimeException implements ExceptionInterface
{    
}
