<?php
namespace CurrencyConverter\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
