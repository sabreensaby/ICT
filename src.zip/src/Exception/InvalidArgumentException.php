<?php

namespace CurrencyConverter\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
