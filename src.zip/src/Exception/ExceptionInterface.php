<?php
namespace CurrencyConverter\Exception;

interface ExceptionInterface
{
}
