<?php

namespace CurrencyConverter\Exception;

class UnsupportedCurrencyException extends InvalidArgumentException implements ExceptionInterface
{
}
